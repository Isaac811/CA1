package org.ca.entity;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
import java.math.BigDecimal;

@Entity
@XmlRootElement(name = "loans")
public class Loans {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "LoanID")
    private int loanId;
    @Basic
    @Column(name = "StudentID")
    private Integer studentId;
    @Basic
    @Column(name = "Reason")
    private String reason;
    @Basic
    @Column(name = "Amount")
    private Double amount;

    public int getLoanId() {
        return loanId;
    }

    public void setLoanId(int loanId) {
        this.loanId = loanId;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Double getAmount() {
        return amount;
    }


    public void setAmount(Double amount) {
        this.amount = amount;
    }
}
