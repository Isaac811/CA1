package org.ca.service;

import org.ca.dao.LoansDao;
import org.ca.entity.Loans;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

@Path("/loans")
public class LoansService {
    private LoansDao loansDao = new LoansDao();
    @POST
    @Path("/addLoan")
    @Consumes("application/json")
    public String addLoan(Loans loan){
        loansDao.persist(loan);
        return "Loan successfully";
    }
}
