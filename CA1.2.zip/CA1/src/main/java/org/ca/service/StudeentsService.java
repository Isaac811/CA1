package org.ca.service;

import org.ca.dao.StudentsDao;
import org.ca.entity.Students;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/students")
public class StudeentsService {

    private StudentsDao studentsDao = new StudentsDao();


    @POST
    @Path("/add")
    @Produces(MediaType.APPLICATION_JSON)
    public String addStudents(Students students) {
        studentsDao.persist(students);
        return "add successfully";
    }


    @POST
    @Path("/getByName")
    @Consumes(MediaType.APPLICATION_XML)
    @Produces(MediaType.APPLICATION_JSON)
    public Students select(Students students) {
        return studentsDao.getStudentByName(students.getName());
    }
}
