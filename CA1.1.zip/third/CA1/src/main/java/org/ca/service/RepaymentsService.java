package org.ca.service;

import org.ca.dao.LoansDao;
import org.ca.dao.RepaymentsDao;
import org.ca.entity.Loans;
import org.ca.entity.Repayments;

import javax.ws.rs.*;
import java.util.List;

@Path("/repayments")
public class RepaymentsService {
    private RepaymentsDao repaymentsDao = new RepaymentsDao();

    private LoansDao loansDao = new LoansDao();

    @POST
    @Path("/repay")
    @Consumes("application/json")
    public String repay(Repayments repayments) {
        Integer loanId = repayments.getLoanId();
        repaymentsDao.persist(repayments);
        Loans loansById = loansDao.getLoansById(loanId);
        if (loansById == null) {
            return "There are no current loans";
        } else {
            Double amount = loansById.getAmount();
            double v = amount - repayments.getAmount();
            if (v < 0) {
                loansById.setAmount(0.0);
                loansDao.merge(loansById);
                return "All the loans have been replaced";
            } else {
                loansById.setAmount(v);
                loansDao.merge(loansById);
                return "You need to pay " + v + "£,back";
            }
        }
    }

    /**
     * get repayments records
     * @param id StudentId
     * @return
     */
    @GET
    @Path("/list/{id}")
    @Produces("application/json")
    public List<Repayments> repayList(@PathParam("id") Integer id) {
        return repaymentsDao.getRepaymentById(id);
    }
}


