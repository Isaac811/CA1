package org.ca.dao;


import org.ca.entity.Loans;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

public class LoansDao {

    public LoansDao() { 

    }

    private static EntityManagerFactory emf =
            Persistence.createEntityManagerFactory("JPAFac");


    public Loans persist(Loans loan) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(loan);
        em.getTransaction().commit();
        em.close();
        return loan;
    }

    public void removeLoan(Loans loan) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.remove(em.merge(loan));
        em.getTransaction().commit();
        em.close();
    }

    public Loans merge(Loans loan) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Loans updateLoan = em.merge(loan);
        em.getTransaction().commit();
        em.close();
        return updateLoan;
    }

    public List<Loans> getAllLoans() {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<Loans> loans = new ArrayList<Loans>();
        loans = em.createQuery("from Loans").getResultList();
        em.getTransaction().commit();
        em.close();
        return loans;
    }

    public Loans getLoansById(int id) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Loans l = em.createQuery("SELECT l FROM Loans l WHERE l.id = :id", Loans.class)
                .setParameter("id", id)
                .getSingleResult();
        em.getTransaction().commit();
        em.close();
        return l;
    }
}
