package org.ca.dao;

import org.ca.entity.Loans;
import org.ca.entity.Repayments;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.ArrayList;
import java.util.List;

public class RepaymentsDao {
    public RepaymentsDao() {

    }
    private static EntityManagerFactory emf =
            Persistence.createEntityManagerFactory("JPAFac");


    public Repayments persist(Repayments repayments) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(repayments);
        em.getTransaction().commit();
        em.close();
        return repayments;
    }

    public void removeRepayment(Repayments repayments) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.remove(em.merge(repayments));
        em.getTransaction().commit();
        em.close();
    }

    public Repayments merge(Repayments repayments) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Repayments updateRepayments = em.merge(repayments);
        em.getTransaction().commit();
        em.close();
        return updateRepayments;
    }

    public List<Repayments> getAllRepayments() {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<Repayments> repayments = new ArrayList<Repayments>();
        repayments = em.createQuery("from Repayments ").getResultList();
        em.getTransaction().commit();
        em.close();
        return repayments;
    }

    public List<Repayments> getRepaymentById(int id) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<Repayments> r = em.createQuery("SELECT r FROM Repayments r WHERE r.studentId = :id", Repayments.class)
                .setParameter("id", id)
                .getResultList();
        em.getTransaction().commit();
        em.close();
        return r;
    }


}
