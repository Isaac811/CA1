package org.ca.entity;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
public class Repayments {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "RepaymentID")
    private int repaymentId;
    @Basic
    @Column(name = "LoanID")
    private Integer loanId;
    @Basic
    @Column(name = "StudentID")
    private Integer studentId;
    @Basic
    @Column(name = "RepaymentDate")
    private String repaymentDate;
    @Basic
    @Column(name = "Amount")
    private Double amount;

    public int getRepaymentId() {
        return repaymentId;
    }

    public void setRepaymentId(int repaymentId) {
        this.repaymentId = repaymentId;
    }

    public Integer getLoanId() {
        return loanId;
    }

    public void setLoanId(Integer loanId) {
        this.loanId = loanId;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getRepaymentDate() {
        return repaymentDate;
    }

    public void setRepaymentDate(String repaymentDate) {
        this.repaymentDate = repaymentDate;
    }

    public Double getAmount() {
        return amount;
    }


    public void setAmount(Double amount) {
        this.amount = amount;
    }
}
