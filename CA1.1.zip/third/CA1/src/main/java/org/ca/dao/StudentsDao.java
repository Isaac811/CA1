package org.ca.dao;

import org.ca.entity.Students;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.ArrayList;
import java.util.List;

public class StudentsDao {
    public StudentsDao() {
    }

    private static EntityManagerFactory emf =
            Persistence.createEntityManagerFactory("JPAFac");


    public Students persist(Students student) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(student);
        em.getTransaction().commit();
        em.close();
        return student;
    }

    public void removeStudent(Students student) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        student = em.merge(student);
        em.remove(student);
        em.getTransaction().commit();
        em.close();
    }

    public Students merge(Students student) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Students updatedStudent = em.merge(student);
        em.getTransaction().commit();
        em.close();
        return updatedStudent;
    }

    public List<Students> getAllStudents() {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        List<Students> students = new ArrayList<>();
        students = em.createQuery("from Students").getResultList();
        em.getTransaction().commit();
        em.close();
        return students;
    }

    public Students getStudentByName(String studentName) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Students s = em.createQuery("SELECT s FROM Students s WHERE s.name = :studentName", Students.class)
                .setParameter("studentName", studentName)
                .getSingleResult();
        em.getTransaction().commit();
        em.close();
        return s;
    }
}
